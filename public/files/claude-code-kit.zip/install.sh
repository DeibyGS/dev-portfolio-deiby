#!/usr/bin/env bash
# Install the kit's skills into your personal skills directory.
#
#   ./install.sh              # install every level
#   ./install.sh level-1      # install one level
#   ./install.sh --dry-run    # show what would happen, change nothing
#
# Skills are copied to ~/.claude/skills/<name>/, which is exactly the path the
# books teach. Nothing is ever overwritten without asking.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"

dry_run=0
levels=""

for arg in "$@"; do
  case "$arg" in
    --dry-run) dry_run=1 ;;
    level-1|level-2|level-3) levels="$levels $arg" ;;
    -h|--help) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown argument: $arg" >&2; exit 2 ;;
  esac
done

[ -z "$levels" ] && levels="level-1 level-2 level-3"

echo "Target: $TARGET"
[ "$dry_run" -eq 1 ] && echo "Mode:   dry run (nothing will be written)"
echo

mkdir -p "$TARGET"

installed=0
skipped=0

for level in $levels; do
  [ -d "$ROOT/skills/$level" ] || continue
  for src in "$ROOT/skills/$level"/*/; do
    [ -f "$src/SKILL.md" ] || continue
    name="$(basename "$src")"
    dest="$TARGET/$name"

    if [ -e "$dest" ]; then
      if diff -rq "$src" "$dest" >/dev/null 2>&1; then
        echo "  = $name (already up to date)"
        skipped=$((skipped + 1))
        continue
      fi
      printf '  ? %s already exists and differs. Overwrite? [y/N] ' "$name"
      if [ "$dry_run" -eq 1 ]; then
        echo "(dry run: would ask)"
        skipped=$((skipped + 1))
        continue
      fi
      read -r reply < /dev/tty
      case "$reply" in
        [yY]) ;;
        *) echo "    skipped"; skipped=$((skipped + 1)); continue ;;
      esac
    fi

    if [ "$dry_run" -eq 1 ]; then
      echo "  + $name (would install)"
    else
      rm -rf "$dest"
      cp -R "$src" "$dest"
      echo "  + $name"
    fi
    installed=$((installed + 1))
  done
done

echo
echo "installed: $installed   skipped: $skipped"
echo
echo "Claude Code picks up new skills without a restart, unless ~/.claude/skills/"
echo "did not exist when your session started. Run /skills to confirm they loaded."
