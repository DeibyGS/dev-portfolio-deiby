# Projects

Starting material for every project and capstone in the collection: the messy
folders, sample documents and datasets the reader works on, so everyone is
working from the same input and can compare their result to the book's.

Planned first: `b1-capstone-document-hub/` — around twenty heterogeneous
documents for the Book 1 capstone.
