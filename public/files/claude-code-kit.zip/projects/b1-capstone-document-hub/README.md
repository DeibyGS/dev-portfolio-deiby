# Capstone: Personal Document Hub

The starting material for the final project of *Claude Code from Zero*,
chapter 13.

Twenty files, deliberately imperfect in the ways real folders are. Work on a
copy:

```bash
cp -r b1-capstone-document-hub hub-practice
cd hub-practice
```

Do not read the rest of this file until you have finished the project.

---

## What's in here (spoilers)

- 7 invoices from 4 suppliers, in two different date formats
- 3 receipts, one with an unreadable date character
- 2 bank statements
- 4 meeting notes
- 1 spreadsheet
- `scan-0044.pdf` — an image with no text layer. It cannot be read.
- `untitled-2.md` — empty
- `invoice-notes.md` — named like an invoice, isn't one
- `archive/notes-2026-01-14.md` — same name as a file in the root,
  **different contents**

That last one is the important one. A duplicate-detection pass that compares
names will call them duplicates. They are not: one says two providers, the
other says three, and one of them approves a budget the other doesn't.
