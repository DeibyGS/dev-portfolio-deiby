# Extraction report

Processed all documents in the folder.

- Documents found: 40
- Rows written: 40
- Fields extracted: reference, date, client, total

No errors encountered. All values read cleanly.
