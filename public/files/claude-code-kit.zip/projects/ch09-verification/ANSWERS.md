# Answers

Read this only after you have run the protocol.

---

## Defect 1 — caught by totals (step 3)

`documents/` contains 40 PDFs. `extracted-table.csv` has 39 rows.

`doc-017.pdf` has no row at all. It was silently dropped.

A missing row is invisible when you read the table — there is no gap, no
blank, nothing out of place. Counting is the only cheap way to see it, which
is why counting comes before everything else.

Note that `report.md` claims 40 rows. The report is wrong, and the report is
not evidence.

---

## Defect 2 — caught by sampling (step 4)

`doc-026.pdf` says one total. The table says `1,728.05`.

Two digits transposed. It looks entirely plausible in the table, sits within
the range of every other value, and nothing about the row draws attention.

You find this by opening documents and comparing — which is why the sample
has to be chosen deliberately rather than by whatever catches your eye. A
transposition in row 26 of 39 is exactly the kind of thing that sits in the
middle where nobody looks.

---

## Defect 3 — caught only by triangulating (step 5)

`documents/scanned/` contains two more PDFs. Neither appears in the table,
and nothing anywhere mentions them.

This is the one that survives the first two steps.

**Counting doesn't catch it:** the root folder holds exactly 40 files, so a
count of the folder agrees with the report.

**Sampling doesn't catch it:** every row in the table is real and, apart from
defect 2, correct. Open ten at random and they all check out.

The only thing that finds it is asking the question a different way — count
the documents recursively rather than at the top level:

```bash
find documents -name '*.pdf' | wc -l     # 42
ls documents/*.pdf | wc -l               # 40
```

Two numbers that should agree, and don't.

This is what triangulation is for. Steps 3 and 4 verify the work that was
done. Only a different route reveals work that was never done at all — and
"processed all documents in the folder" was true of the folder the tool
looked at, and false of the folder you meant.
