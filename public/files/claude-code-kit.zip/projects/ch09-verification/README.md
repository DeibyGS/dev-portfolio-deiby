# Chapter 9: Find the three defects

`documents/` holds the source files. `extracted-table.csv` is a finished
extraction, and `report.md` is the summary that came with it.

**The table contains three defects.**

- One you will catch by checking totals
- One you will catch by sampling
- One you will only catch by triangulating

Run the six-step acceptance protocol from chapter 9. Write down which step
caught which defect **before** you open `ANSWERS.md`.

That mapping is the exercise. Finding three defects when you have been told
there are three is easy. Knowing which technique was required for each is the
skill being trained.
