# Skill index

Every skill, the chapter that introduces it, and its identifier in the books.
Code blocks in the manuscript carry the same identifier, so a change here is a
diff rather than a search through 600 pages.

## Level 1 — Book 1

Frontmatter is `description` only. That is the whole point: Book 1 chapter 11
teaches a skill you can write in five minutes, and these are what that looks like.

| Skill | Identifier | Introduced in | Used again in |
|---|---|---|---|
| `/summarize-folder` | `B1-C05-S01` | Ch. 5 — Your first project: a folder | Ch. 11 (built from scratch), capstone |
| `/extract-data` | `B1-C07-S02` | Ch. 7 — Working with documents and data | Ch. 9, capstone |
| `/compare-versions` | `B1-C07-S03` | Ch. 7 — Working with documents and data | Ch. 8 |
| `/clean-text` | `B1-C07-S04` | Ch. 7 — Working with documents and data | — |
| `/acceptance-checklist` | `B1-C09-S05` | Ch. 9 — How to know whether the result is correct | Capstone, and Books 2–3 throughout |

**Chapter 11 note.** The reader writes `/summarize-folder` from an empty file: it is
the simplest of the five and its output is immediately checkable against the folder
in front of them. The other four are installed from the kit and read as examples.

**A design rule these five follow.** Every one of them ends by stating what it did
*not* do — files it could not open, values it could not read, comparisons it could
not make. That is not padding. It is the collection's thesis expressed as a file:
a result you cannot audit is not a result.

## Level 2 — Book 2

Not yet written. Ten skills planned, introducing full frontmatter, arguments,
supporting files and dynamic context injection. See the collection architecture,
section 9.

## Level 3 — Book 3

Not yet written. Ten skills planned, covering composition, forked context,
distribution and cost control. See the collection architecture, section 9.
