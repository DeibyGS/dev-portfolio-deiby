# Level 2 skills — Book 2

Ten skills that introduce the rest of the frontmatter: arguments, supporting
files, dynamic context injection, tool restrictions and path scoping.

Not yet written. Planned: `/batch-process`, `/weekly-report`, `/style-review`,
`/project-status`, `/translate-keep-format`, `/prep-meeting`, `/audit-claude-md`,
`/normalize-data`, `/generate-docs`, `/publish-draft`.
