---
description: Compares two versions of a document and separates changes that alter the meaning from changes that do not. Use when the user asks what changed between two files, wants to review edits to a contract, proposal or draft, or asks which version is newer.
---

# Compare two versions

A raw list of differences is not useful. The user needs to know which changes
matter. Sort them by consequence, not by position in the file.

## Steps

1. **Confirm both files** and which one is the earlier version. If it is not obvious
   from names or dates, ask. Getting the direction wrong inverts the whole report.

2. **Read both documents in full** before writing anything. Comparing section by
   section as you read produces noise, not analysis.

3. **Sort every difference into one of three groups:**

   - **Substantive** — changes the meaning, the obligations, the numbers, the
     conclusions, or what someone would do differently after reading it.
   - **Structural** — content moved, split, merged, reordered, or renamed, without
     the meaning changing.
   - **Cosmetic** — wording, punctuation, formatting, typo fixes.

   When a change could be substantive, treat it as substantive. Say why you were
   unsure.

4. **Report in this order:**

   - **Verdict**: two or three sentences on what actually changed between these
     versions.
   - **Substantive changes**: a table with the section, what the old version said,
     what the new one says, and why it matters.
   - **Structural changes**: a short list.
   - **Cosmetic changes**: a count only, not a list, unless the user asks for it.

5. **Flag removals separately.** Content that disappeared is the easiest thing to
   miss and often the most important. Give deletions their own list, even when they
   are also listed above.

## Rules

- Never say "no significant changes" without stating what you compared. Say which
  sections you checked.
- If the two documents are structured differently enough that sections cannot be
  matched, say so and compare by topic instead — do not force a false alignment.
- If one file could not be read completely, report the comparison as partial and
  name the part you could not cover.
- Do not edit either file. This skill only reads.
