---
description: Turns a task into a checklist of acceptance criteria you can verify afterwards, and names what cannot be checked automatically. Use before delegating a task, when the user asks how they will know the result is correct, or when defining what "done" means.
---

# Build an acceptance checklist

Run this **before** the work, not after. Criteria written after seeing the result
describe the result, not the requirement.

## Steps

1. **Restate the task in one sentence**, as you understand it. If your restatement
   and the user's request differ, resolve that before going further — most bad
   results start here.

2. **Identify the deliverable.** What exact artifact will exist when this is done: a
   file, a table, a document, a change to something? If the answer is vague, the
   task cannot be accepted or rejected. Ask.

3. **Write the criteria.** Each one must be a statement that is plainly true or
   false when you look at the finished work. Aim for five to ten.

   - Good: "The table has one row per source document, including failed ones."
   - Bad: "The table is complete." — complete against what?

   Cover four areas:
   - **Content** — what must be present
   - **Form** — format, structure, naming, location
   - **Limits** — what must *not* happen, what must not change
   - **Volume** — counts that must match, totals that must reconcile

4. **Separate the criteria into two lists:**

   - **Checkable** — a person or a script can confirm it in under a minute.
   - **Requires judgement** — someone has to read it and decide. Say who, and what
     they should be looking for.

   Never move something into "checkable" by making it vaguer.

5. **Define the sample.** If the work covers many items, state how many will be
   checked by hand, which ones, and how they are chosen. "Spot check" is not a
   plan; "the first, the last, and three at random" is.

6. **Name the failure condition.** What result would mean this has to be redone
   rather than patched? One sentence.

## Output

```
TASK
<one sentence>

DELIVERABLE
<the exact artifact>

CHECKABLE
[ ] ...

REQUIRES JUDGEMENT
[ ] ...  (who checks: ...)

SAMPLE
<how many, which ones, chosen how>

REDO IF
<one sentence>
```

## Rules

- Do not start the task itself. This skill produces the checklist and stops.
- If the user cannot say what the deliverable is, that is the finding. Report it
  instead of inventing criteria around a guess.
- Criteria that only the person who did the work can verify are worthless. If a
  criterion cannot be checked by someone else, rewrite it or move it to
  "requires judgement" with a named checker.
