---
description: Extracts the same fields from a batch of documents into one table, marking anything missing rather than guessing. Use when the user needs data pulled out of several invoices, forms, reports, contracts or emails, or asks to turn a folder of documents into a spreadsheet.
---

# Extract data into a table

The value of this task is a table the user can trust. A confident wrong number is
worse than a blank cell, so every uncertain value must be visible as uncertain.

## Steps

1. **Agree the fields before extracting anything.** If the user did not list the
   fields they want, read two or three of the documents, propose a field list, and
   wait for confirmation. Do not extract a field nobody asked for.

2. **Agree the output format**: a Markdown table in the reply, a CSV file, or both.
   If they want a file, confirm the filename and location before writing it.

3. **Process the documents one at a time.** For each one, extract only the agreed
   fields. Use exactly the value that appears in the document — do not reformat
   dates, currencies or names unless the user asked you to normalize them.

4. **Use these markers instead of guessing:**

   | Marker | Meaning |
   |---|---|
   | `MISSING` | The field is genuinely absent from this document |
   | `UNCLEAR: <what you saw>` | Something is there but you cannot read it confidently |
   | `MULTIPLE: <values>` | The document contains more than one candidate value |

   Never leave a cell blank, and never fill one from context, from another
   document, or from what the value "should" be.

5. **Build the table.** One row per document. The first column is always the source
   filename, so every row can be traced back.

6. **Report on the batch.** After the table, give:
   - how many documents were processed, and how many were skipped and why
   - a count of `MISSING`, `UNCLEAR` and `MULTIPLE` cells per field
   - the three rows you are least confident about, and why

## Rules

- One row per source document, always, even if the extraction failed for that
  document. A missing row is invisible; a row full of `MISSING` is not.
- If a field is `MISSING` or `UNCLEAR` in more than a third of the documents, stop
  and tell the user before finishing — the field is probably wrong or the documents
  are not as uniform as expected.
- Do not correct what the document says, even when it is obviously a typo. Extract
  the value as written and flag it in the confidence report.
- If a document contains personal or financial data the user did not ask for, do not
  copy it into the table.
