---
description: Inventories a folder and produces a summary table of what is inside it. Use when the user asks what is in a folder, wants an overview of a messy directory, needs a table of contents for a set of files, or asks "what do I have here?".
---

# Summarize a folder

Produce an inventory the user can act on. Do not open every file — read enough to
classify each one, and say plainly what you did not read.

## Steps

1. **Confirm the target.** If the user did not name a folder, ask which one before
   doing anything. Do not assume the current directory.

2. **List the contents**, including subfolders, one level at a time. Note the total
   file count and the total size.

3. **Classify each file** into a small set of groups that fit what you actually
   found — for example: documents, spreadsheets, images, data, archives, unknown.
   Invent the groups from the contents; do not force a fixed list.

4. **Open only what you need** to classify or describe a file. For long files, read
   the beginning and enough of the rest to say what it is. Never read a file just to
   be thorough.

5. **Produce the summary** in this order:

   - **One paragraph**: what this folder appears to be, in plain language.
   - **A table** with one row per file: name, group, size, and a one-line
     description.
   - **Things worth a second look**: duplicates or near-duplicates, files with no
     clear purpose, empty files, files whose name does not match their contents,
     anything unusually large or old.

6. **State your limits explicitly.** End with a short section listing:
   - files you could not open, and why
   - files you classified from the name alone without opening them
   - anything you are unsure about

## Rules

- Never guess what a file contains. If you did not open it, say so in the limits
  section.
- Do not modify, move, rename or delete anything. This skill only reads.
- If the folder holds more than about 200 files, summarize by group first and ask
  whether the user wants the full per-file table before producing it.
- If you find something that looks like credentials, a `.env` file, or personal
  data, name the file and stop reading it. Do not quote its contents.
