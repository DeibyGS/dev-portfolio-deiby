---
description: Repairs text damaged by copying and pasting — broken line breaks, hyphenation from PDFs, smart quotes, stray spacing — without changing a single word. Use when the user pastes text from a PDF, email, slide deck or web page and it comes out badly formatted.
---

# Clean pasted text

This skill fixes **how the text is written down**, never **what it says**. The user
must be able to hand the result back to its author without an argument.

## Steps

1. **Confirm the source and the destination.** Where is the text, and where should
   the cleaned version go — back in the reply, or into a file? If into a file,
   confirm the name before writing. Never overwrite the original.

2. **Apply only these repairs:**

   | Problem | Repair |
   |---|---|
   | Line breaks mid-sentence | Join into continuous paragraphs |
   | Words split across lines (`admin-\nistration`) | Rejoin into one word |
   | Curly quotes and dashes pasted as odd characters | Replace with the correct character |
   | Double or multiple spaces | Reduce to one |
   | Trailing spaces at end of lines | Remove |
   | Non-breaking spaces and zero-width characters | Replace with a normal space, or remove |
   | Page numbers, headers and footers repeated mid-text | Remove, and report how many |
   | Bullet characters pasted as symbols | Convert to a normal list |

3. **Preserve everything else exactly**: word choice, sentence order, paragraph
   breaks that were intentional, capitalisation, spelling, numbers, names, and any
   error the author made.

4. **Report what you changed**, grouped by the categories above with a count for
   each. If you removed repeated headers or page numbers, quote one example so the
   user can confirm it was not real content.

5. **Ask before anything ambiguous.** A hyphen that might belong to the word
   (`self-service` split across lines) is a judgement call — list these and ask
   rather than deciding silently.

## Rules

- **Never rewrite, rephrase, shorten, translate or improve the text.** If the user
  wants that, it is a different task and you should say so.
- Never fix spelling or grammar. A typo is content, not formatting damage.
- If the text contains something that reads as a heading or a table, preserve its
  structure rather than flattening it into a paragraph.
- If more than a third of the text needed repair, say so — the source may be worth
  re-exporting rather than cleaning.
