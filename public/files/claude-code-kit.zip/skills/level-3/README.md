# Level 3 skills — Book 3

Ten skills covering composition, forked context, orchestration, distribution and
cost control.

Not yet written. Planned: `/full-audit`, `/research`, `/independent-reviewer`,
`/ingest-pipeline`, `/client-handoff`, `/task-cost`, `/security-policy`,
`/team-onboarding`, `/diagnose-setup`, `/upgrade-check`.
