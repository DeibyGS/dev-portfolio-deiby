#!/usr/bin/env bash
# Validate every SKILL.md in the kit against the rules verified in
# docs/TECHNICAL-CORE.md section 4.3 (Claude Code v2.1.223).
#
# Usage:  tools/validate-skills.sh [skills-dir]
# Exit:   0 = all valid, 1 = at least one error

set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SKILLS_DIR="${1:-$ROOT/skills}"

DESC_LIMIT=1536   # description + when_to_use, truncated in the skill listing

errors=0
warnings=0
checked=0

red()   { printf '\033[31m%s\033[0m\n' "$1"; }
amber() { printf '\033[33m%s\033[0m\n' "$1"; }
green() { printf '\033[32m%s\033[0m\n' "$1"; }

fail() { red   "  ERROR   $1"; errors=$((errors + 1)); }
warn() { amber "  WARN    $1"; warnings=$((warnings + 1)); }

if [ ! -d "$SKILLS_DIR" ]; then
  red "No skills directory at $SKILLS_DIR"
  exit 1
fi

# Frontmatter block: lines strictly between the first '---' and the next '---'.
frontmatter() {
  awk 'NR==1 && $0!="---" { exit }
       NR==1 { infm=1; next }
       infm && $0=="---" { exit }
       infm { print }' "$1"
}

# Top-level keys in the frontmatter.
fm_keys() {
  frontmatter "$1" | awk -F: '/^[a-zA-Z][a-zA-Z0-9_-]*:/ { print $1 }'
}

# Value of a key, including indented continuation lines.
fm_value() {
  frontmatter "$1" | awk -v key="$2" '
    $0 ~ "^" key ":" { sub("^" key ":[[:space:]]*", ""); print; found=1; next }
    found && /^[[:space:]]+[^[:space:]]/ { sub("^[[:space:]]+", " "); printf "%s", $0; next }
    found { exit }'
}

while IFS= read -r skill; do
  dir="$(dirname "$skill")"
  name="$(basename "$dir")"
  level="$(basename "$(dirname "$dir")")"
  checked=$((checked + 1))

  printf '\n%s  (%s)\n' "$name" "$level"
  errors_before=$errors

  # --- directory name ------------------------------------------------------
  case "$name" in
    *[!a-z0-9-]* | -* | *- )
      fail "directory name '$name' must be lowercase-kebab-case; it becomes the /command" ;;
  esac

  # --- frontmatter present -------------------------------------------------
  if [ "$(head -n 1 "$skill")" != "---" ]; then
    fail "file does not start with '---' — frontmatter will not be parsed"
    continue
  fi
  if [ "$(frontmatter "$skill" | wc -l | tr -d ' ')" = "0" ]; then
    fail "frontmatter block is empty or never closed with '---'"
    continue
  fi

  keys="$(fm_keys "$skill")"

  # --- description ---------------------------------------------------------
  if ! printf '%s\n' "$keys" | grep -qx "description"; then
    fail "no 'description' field — Claude cannot tell when to load this skill"
  else
    desc="$(fm_value "$skill" description)"
    when="$(fm_value "$skill" when_to_use)"
    len=$(( ${#desc} + ${#when} ))
    if [ "$len" -gt "$DESC_LIMIT" ]; then
      fail "description + when_to_use is $len chars; truncated at $DESC_LIMIT in the listing"
    elif [ "$len" -gt $(( DESC_LIMIT * 8 / 10 )) ]; then
      warn "description + when_to_use is $len chars, close to the $DESC_LIMIT limit"
    fi
    if [ "${#desc}" -lt 40 ]; then
      warn "description is only ${#desc} chars — too vague to trigger reliably"
    fi
    # The description must state a trigger, not only what the skill does.
    if ! printf '%s' "$desc" | grep -Eqi '(use|trigger|invoke)[[:space:]]+(when|before|after|if|for|to)'; then
      warn "description does not state WHEN to use the skill"
    fi
  fi

  # --- level-1 purity ------------------------------------------------------
  if [ "$level" = "level-1" ]; then
    extra="$(printf '%s\n' "$keys" | grep -vx "description" || true)"
    if [ -n "$extra" ]; then
      warn "level-1 skills teach 'description + body' only; found: $(echo "$extra" | tr '\n' ' ')"
    fi
  fi

  # --- unknown fields ------------------------------------------------------
  known="name description when_to_use argument-hint arguments disable-model-invocation user-invocable allowed-tools disallowed-tools model effort context agent background hooks paths shell metadata license compatibility"
  while IFS= read -r k; do
    [ -z "$k" ] && continue
    case " $known " in
      *" $k "*) ;;
      *) fail "unknown frontmatter field '$k' (see TECHNICAL-CORE.md 4.3)" ;;
    esac
  done <<EOF
$keys
EOF

  # --- body ----------------------------------------------------------------
  body_lines="$(awk 'NR>1 && $0=="---" { found=NR; exit } END { print found+0 }' "$skill")"
  total="$(wc -l < "$skill" | tr -d ' ')"
  if [ "$(( total - body_lines ))" -lt 5 ]; then
    fail "body is empty or too short to be useful"
  fi

  if [ "$errors" -eq "$errors_before" ]; then
    printf '  ok      %s lines, description %s chars\n' "$total" "${#desc}"
  fi
done < <(find "$SKILLS_DIR" -name SKILL.md -type f | sort)

printf '\n──────────────────────────────────────────\n'
printf 'checked: %s skills   errors: %s   warnings: %s\n' "$checked" "$errors" "$warnings"

if [ "$errors" -gt 0 ]; then
  red "FAILED"
  exit 1
fi
green "PASSED"
exit 0
