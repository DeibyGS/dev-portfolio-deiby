# Templates

Annotated starting files the books tell you to copy.

Planned: `CLAUDE.md` variants by project type (code, content, documents, data),
`settings.json` permission profiles (explore / produce / client), project folder
structures, and an acceptance-criteria template.
