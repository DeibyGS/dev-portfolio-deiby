# Versions and compatibility

## How this kit is versioned

The kit follows `MAJOR.MINOR.PATCH`:

| Change | Bump | Example |
|---|---|---|
| A skill's behaviour or interface changes in a way the book describes differently | **MAJOR** | A skill is renamed, or its steps change |
| New skills, templates or checklists added | **MINOR** | Level 2 skills ship |
| Fixes, wording, re-verification against a newer Claude Code | **PATCH** | A field name changed upstream |

Every release records the Claude Code version it was verified against. That is the
number that matters: the kit is only guaranteed against versions it has been checked
on.

## Compatibility log

| Kit | Verified against | Date | Notes |
|---|---|---|---|
| 0.1.0 | Claude Code v2.1.223 | 2026-08-07 | Initial skeleton, five Level 1 skills |

## If your Claude Code is newer

Claude Code ships changes weekly, so being ahead of the table above is normal and
usually harmless. The Level 1 skills use only `description` plus instructions —
the most stable surface there is — so they are the least likely thing to break.

If something does misbehave:

1. `claude --version` and `/doctor` — confirm the skill actually loaded.
2. `/skills` — confirm the name you expect is listed.
3. Check the compatibility log above for a newer kit release.

## What is most likely to change upstream

Ordered by how likely they are to move, based on the change history at the time of
writing:

| Area | Affects |
|---|---|
| Skill frontmatter fields | Level 2 and 3 skills |
| The 1,536-character description limit | `tools/validate-skills.sh` |
| Bundled skill names and behaviour | Book references to `/verify`, `/code-review`, `/batch` |
| Hook events and handler types | `hooks/` |
| Auto mode's default block list | Nothing in this repo — it is deliberately never hard-coded here |
| Permission mode names | `templates/settings.json` |

Level 1 skills appear in none of these rows. That is by design.
