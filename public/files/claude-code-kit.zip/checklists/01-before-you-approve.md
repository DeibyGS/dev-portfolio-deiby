# Before You Approve an Action

*Claude Code from Zero — chapter 4*

- [ ] Do I understand what this command does?
- [ ] Does it write or delete, or only read?
- [ ] Is the target inside my working folder?
- [ ] Does it touch `.env`, keys, certificates, or credentials?
- [ ] Does it send anything off my machine?
- [ ] Could I undo this in under a minute?
- [ ] Did I ask for this, or did it decide on its own?
- [ ] If I'm unsure — have I asked what it does before approving?

---

**If you don't understand the command, don't approve it. Ask what it does
first.** That is a legitimate use of the tool, not an admission of ignorance.

---

### Almost always fine

Reading files inside your working folder · listing directories · anything
that only produces text back to you.

**The one exception:** reading a file that holds secrets — `.env`, keys,
certificates — puts its contents into the conversation. That read belongs in
the list below, not this one.

### Never without reading it properly

Anything that deletes · anything that writes outside your working folder ·
anything that sends data somewhere · anything touching `.env`, keys or
certificates · any command you can't read.
