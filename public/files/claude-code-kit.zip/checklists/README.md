# Checklists

Five single pages, formatted for printing.

| File | From |
|---|---|
| `01-before-you-approve.md` | Chapter 4 — permissions and safety |
| `02-before-you-send-an-instruction.md` | Chapter 6 — instructions that work |
| `03-acceptance-protocol.md` | Chapter 9 — knowing it's correct |
| `04-starting-a-project-folder.md` | Chapters 4, 5, 10 |
| `05-ten-second-audit.md` | Chapter 12 — twelve mistakes |

The two worth actually printing and keeping next to you are **01** and **03**.
The rest you'll internalize within a month.

## Printing them

They're Markdown. Any Markdown viewer prints them acceptably. For something
tidier:

```bash
pandoc 03-acceptance-protocol.md -o acceptance.pdf
```

`03` has blanks to fill in by hand, which is the point — a sample you wrote
down is a record, and a sample you remember is not.
