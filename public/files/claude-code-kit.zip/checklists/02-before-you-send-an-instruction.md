# Before You Send an Instruction

*Claude Code from Zero — chapter 6*

- [ ] Can I name the exact artifact I expect?
- [ ] Is the goal an outcome, not a procedure?
- [ ] What does it need to know that it can't see?
- [ ] What will I check when it comes back?
- [ ] Is this one task, or three pretending to be one?
- [ ] Have I said what it must *not* do?
- [ ] Is there a word here that isn't doing work?

---

## GCVD

| | | Answers |
|---|---|---|
| **G** | Goal | What outcome do you want? |
| **C** | Context | What must it know that it can't see? |
| **V** | Verification | How will you know it worked? |
| **D** | Deliverable | What exactly should exist at the end? |

**Not every instruction needs all four.** It's a checklist for when something
went wrong, not a form to fill in every time.

**Write the deliverable first.** If you can't, you don't yet know what you
want, and no amount of describing will fix that.

---

## Writing one, in order

1. The deliverable. One line.
2. The goal, as an outcome. One sentence.
3. What it can't see.
4. One thing you'll check.
5. Delete every word that isn't doing work.
