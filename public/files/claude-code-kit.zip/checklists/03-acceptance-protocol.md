# The Six-Step Acceptance Protocol

*Claude Code from Zero — chapter 9*

- [ ] **1. Criteria written BEFORE asking**
- [ ] **2. Limits section requested** in the instruction
- [ ] **3. Totals checked** — counts in, counts out
- [ ] **4. Sample chosen deliberately** — first, last, three at random
- [ ] **5. One claim triangulated** by a different route
- [ ] **6. Verdict stated** — accept, fix, or redo

---

**Which items did I sample?**

```
1. ______________________   4. ______________________

2. ______________________   5. ______________________

3. ______________________
```

**Which claim did I triangulate, and how?**

```
_________________________________________________________
```

**Verdict:**   ☐ accept    ☐ fix    ☐ redo

**Reason:** ______________________________________________

---

"I looked at some" is not a record. Write down which ones.

If the verdict is fix or redo: **change the instruction, not the output.**
A corrected output is a one-off. A corrected instruction is reusable.

---

### Triangulation means checking by a different route

Asking the same tool the same question again is not a check. Neither is
asking "are you sure?" — you'll get a confident yes, produced by the same
reasoning that produced the original answer.

### Signals worth a second look

No gaps or caveats at all · round numbers where you expected messy ones ·
every record complete when the source obviously wasn't · a confident
description of a file it couldn't open · **no limits section at all**.
