# Starting a New Project Folder

*Claude Code from Zero — chapters 4, 5, 10*

- [ ] I'm in the right folder — checked with `pwd`
- [ ] It's a copy, or it's under version control
- [ ] I know the folder well enough to check the answers
- [ ] It's small enough to work with (under a few hundred files)
- [ ] I've looked for credentials or personal data before pointing
      anything at it
- [ ] There's a `CLAUDE.md`, even if it's four lines

---

## Setting up

```bash
pwd                    # where am I?
git init
git commit -m "before" # after staging the files you want
claude
```

Then, inside the session:

```
/init
```

Delete everything it generated that could be discovered by looking. Add what
it couldn't have known.

---

## What belongs in CLAUDE.md

**In:** things you'd have to say twice · conventions · which folder is
authoritative · the exception you always forget to mention · formats you want
followed · things that broke once.

**Out:** anything discoverable by looking. Folder structures, file lists,
long descriptions of what the project is.

**The test:** would a new colleague need to be told this, or would they find
it in five minutes?

**Keep it under 200 lines.** Long files get followed less reliably, not more.
