# When Something Goes Wrong: The Ten-Second Audit

*Claude Code from Zero — chapter 12*

- [ ] Am I in the right folder?
- [ ] Is this one task or several?
- [ ] What did I know that I didn't say?
- [ ] Did I actually read the diff?
- [ ] Is this attempt one, two, or three?
- [ ] Did I check anything, or did it just look right?

---

**If you're on attempt three, stop.**

Rewind, work out what the instruction didn't say, and start again. The rounds
you already spent are the sunk cost. The next one is the mistake.

---

## The pattern underneath most failures

**Not saying enough** — the instruction was incomplete, and an incomplete
instruction produces a confident, plausible, wrong result rather than an
error message.

**Not looking** — the information was there and nobody read it.

**Not stopping** — something was going wrong and it kept going.

> ### Say more, look harder, stop sooner.

---

## Recovery, in order

1. `Escape` — stop what's happening now
2. `/rewind` — roll conversation and files back
3. `git checkout <file>` — if the folder is under version control
4. Your backup

If none of those apply, set up version control before you continue.
