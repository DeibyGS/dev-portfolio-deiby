# Hooks

Copy-paste hooks, each annotated with the event it uses and what it guarantees.

Not yet written. Planned for Book 2 ch. 9: format after edit, log every session,
block writes to protected files, warn on a long session, and notify on finish.
