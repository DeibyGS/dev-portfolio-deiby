# Licence

Copyright © 2026 Deiby Gorrín. All rights reserved.

This repository accompanies *Claude Code from Zero* and is supplied to people
who obtained a copy of the book.

---

## The short version

| Question | Answer |
|---|---|
| Can I use this at work? | Yes |
| Can I modify it? | Yes |
| Can I use my modified versions commercially, including for clients? | **Yes** |
| Can I share the repository with a colleague? | No — they get their own copy |
| Can I publish it, resell it, or put it in a public repo? | No |
| Who owns what I produce with it? | You do |

The rest of this document says the same thing more carefully.

---

## 1. What this licence covers

Everything in this repository: code, skills, templates, hooks, scripts,
configuration files, example documents, checklists, prompts and documentation.
They are referred to below as **the Materials**.

## 2. What you are granted

A **personal, non-exclusive, non-transferable licence** to use the Materials.

You may:

- use them for your own work, personal or professional
- use them in the course of your employment
- modify and adapt them freely
- **incorporate modified versions of the skills, templates, hooks and
  configuration into your own projects, including commercial projects and work
  delivered to clients**

That third point is deliberate. These Materials exist to be used in real work.
A skill you cannot adapt for a client is a skill you cannot use.

This licence grants a right to use. **It does not transfer ownership** of the
repository or its contents. Rights not expressly granted are reserved.

## 3. What you may not do

You may not:

- redistribute the repository, or substantial portions of it, modified or not
- make it publicly available — including through public or unrestricted code
  repositories, websites, file-sharing services, or similar platforms
- sell it, sublicense it, or include it in another product offered for sale
- share your copy, or access to it, with anyone who has not obtained the book
  themselves

**"Substantial portions"** means, in practice: the repository as a whole, a
complete directory from it, most of the skills or templates, or a collection
assembled mainly from these Materials. Adapting an individual skill or template
into your own work is exactly what section 2 permits and is not affected.

## 4. One person, one licence

This is an individual licence. Buying the book licenses **you**.

You may use the Materials in the organisation you work for, provided that you
are the person using them and that they are not distributed or made available
to colleagues who have not obtained their own copy.

If several people on a team need access, each needs their own copy. If that is
impractical for your organisation, contact me — a team arrangement is
straightforward.

## 5. What you produce

You retain whatever rights you have in original output you create using the
Materials. I claim no ownership of it.

You are responsible for ensuring that your use of the Materials, and anything
you produce with them, complies with applicable law, with any third-party
licences involved, and with the terms of the software and services you use.

## 6. Third-party materials

Some Materials reference or interoperate with software, services and
documentation owned by other people. Those remain subject to their own licences
and terms, which this licence neither replaces nor overrides.

Claude and Claude Code are trademarks of their respective owners. This
repository and the book it accompanies are independent works, not affiliated
with, authorised by, or endorsed by Anthropic.

## 7. No warranty

The Materials are provided **"as is"**, without warranties of any kind, express
or implied, to the fullest extent permitted by applicable law.

They are tested, and the version of Claude Code they were verified against is
recorded in `VERSION.md`. That is not a guarantee that they will work in your
environment, on your version, or on your data.

**Test them on something you can afford to break before you use them on
something you can't.** The book says the same thing rather more often.

To the extent permitted by law, I am not liable for any loss or damage arising
from use of the Materials.

## 8. If this licence is breached

This licence terminates automatically if you materially breach its terms.

On termination you must stop using the Materials and delete the copies in your
possession or control, except where retention is required by law.

## 9. Questions

If something here is unclear, or your situation doesn't fit — a team, a
classroom, an agency — ask. The intent of this licence is to let you use these
Materials in your work while stopping the repository from being republished as
someone else's product. Most questions resolve easily against that intent.

---

*This licence is written to be read. It is not a substitute for legal advice,
and it does not limit any rights you have under your local consumer law.*
