# Twenty Instructions Worth Keeping

The instructions from Appendix B of *Claude Code from Zero*, as plain text so
you can copy them without retyping from a screen.

Replace anything in `<angle brackets>`.

Each one is written the way chapter 6 recommends: a named deliverable, the
context the tool cannot see, and something you can check afterward.

## Understanding a folder

**1. Inventory**

```
Inventory this folder. Group the files by what they actually
are — invent the groups from what you find. Give me a table:
filename, group, size, one-line description. End with the files
you couldn't open and the ones you classified from the name
alone.
```

**2. What changed recently**

```
Which files here were modified in the last <30> days? Table
with filename, date, and what you think changed. Say which ones
you inferred rather than checked.
```

**3. Find the odd ones out**

```
Files here should follow the pattern <YYYY-MM-topic.pdf>. List
every file that doesn't, with what's wrong. Don't rename
anything.
```

**4. Find duplicates properly**

```
Find likely duplicate files. Compare by CONTENT, not by name.
Give me the groups, and say for each whether you compared
contents or only names. Don't delete anything.
```

---

## Getting data out

**5. The extraction template**

```
From every <PDF> in <./folder/>, extract: <field1>, <field2>,
<field3>.

Don't reformat values — give me exactly what the document says.
If a value is missing write MISSING; if it's there but you
can't read it confidently write UNCLEAR and what you saw. Never
guess and never fill a value in from another document.

Deliverable: <output.csv>, one row per file, filename first
column, including files that failed.

Then tell me how many files you processed and count the MISSING
and UNCLEAR cells per column.
```

**6. Extract into an existing shape**

```
Extract the same fields as in <existing.csv> from the new files
in <./inbox/>. Match the existing column order exactly. Append,
don't replace. Tell me how many rows you added.
```

**7. Reconcile two lists**

```
Compare <list-a.csv> and <list-b.csv> on the <invoice number>
column. Give me three lists: in A only, in B only, in both but
with different <amounts>. Don't modify either file.
```

---

## Reading and comparing

**8. Compare two versions**

```
Compare <file-v1> and <file-v2>. Sort the differences into:
changes that affect meaning, content that moved without
changing, and cosmetic. Give me the first as a table, the
second as a list, the third as a count. List anything REMOVED
separately.
```

**9. Cross-document question**

```
Read every file in <./folder/> and answer: <question>. Cite
which file each part of the answer came from. Say which files
didn't contribute anything.
```

**10. Find contradictions**

```
Read <document>. List anything that contradicts something said
earlier in the same document, with locations. Just the
contradictions — don't rewrite anything.
```

**11. Summarize for a purpose**

```
Summarize <these documents> for <who> who needs to decide
<what>. Only what's relevant to that decision. Say what you
left out.
```

---

## Producing things

**12. Fill a template**

```
Using <template.md> as the exact structure, produce one file
per <item> in <./source/>. Fill only the fields the source
supports; leave the rest as TODO rather than inventing them.
```

**13. Convert format**

```
Convert every <.docx> in this folder to Markdown, preserving
headings, lists and tables. Keep the original files. Put the
results in <./converted/>. List anything that didn't survive
the conversion.
```

**14. Clean pasted text**

```
Fix the formatting of this text only: rejoin broken lines and
split words, fix quotes and dashes, collapse multiple spaces,
remove repeated headers. Do NOT change a single word — no
rewriting, no spelling or grammar fixes. Report what you
changed by category with counts.
```

**15. Recurring report**

```
From <source>, produce <report.md> with these sections:
<section list>. Same structure every time so I can compare
month to month. If a section has no data, include it and say "no
data" rather than omitting it.
```

---

## Batch operations

**16. Propose before acting**

```
<Describe the change> across every file in this folder. Show me
the full list of proposed changes before you make any of them.
I'll tell you which to apply.
```

**17. Rename to a pattern**

```
Rename every file here to <YYYY-MM-DD-topic.ext>, taking the
date and topic from inside the document. Like this:
<2026-03-14-budget-review.pdf>. Show me the complete list of
proposed renames before changing anything.
```

**18. Process in batches with checkpoints**

```
Process the files in <./folder/> in batches of 10. After each
batch, report what you did and stop for my confirmation before
continuing. Keep a running count.
```

---

## Checking

**19. Acceptance criteria, before you start**

```
I'm about to ask for: <task>. Before we begin, write the
acceptance criteria: five to ten statements that are plainly
true or false when I look at the result. Separate the ones I
can check mechanically from the ones needing judgement. Don't
start the task.
```

**20. Independent review**

```
Here's what I asked for: <requirement>. Here's what I got:
<result>. You have no knowledge of how it was produced. Check
it against the requirement and list every discrepancy. Say what
you couldn't verify.
```

Use 20 in a fresh session after `/clear`. Asking in the same conversation
gets you agreement, not review — chapter 9 explains why.
