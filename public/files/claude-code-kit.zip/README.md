# Claude Code Kit

The companion repository for the **Claude Code: From Terminal to System** collection.

Everything shown in the books lives here, working and tested. When a new version of
Claude Code changes something, this repository is updated — the books point here on
purpose, so what you have keeps working.

| | |
|---|---|
| **Kit version** | 0.1.0 |
| **Verified against** | Claude Code v2.1.223 |
| **Last verified** | 7 August 2026 |

Check what you are running with `claude --version`. If your version is much newer
than the one above, see [VERSION.md](VERSION.md) before assuming something is broken.

---

## Install

```bash
./install.sh --dry-run     # see what would happen
./install.sh level-1       # install just the beginner skills
./install.sh               # install everything
```

Skills are copied to `~/.claude/skills/<name>/` — the same path the books teach, so
you can open any of them and read the file you were shown how to write.

Nothing is overwritten without asking. To install somewhere else, set
`CLAUDE_SKILLS_DIR`.

After installing, open Claude Code and run `/skills` to confirm they loaded. Claude
Code picks up new skills without restarting, unless `~/.claude/skills/` did not
exist when your session started.

---

## What is in here

| Directory | Contents | Book |
|---|---|---|
| `skills/level-1/` | Five beginner skills: `description` + instructions, nothing else | Book 1 |
| `skills/level-2/` | Skills using full frontmatter, arguments, supporting files | Book 2 |
| `skills/level-3/` | Composite, isolated and distributable skills | Book 3 |
| `templates/` | `CLAUDE.md`, `settings.json`, project structures | Books 1–3 |
| `checklists/` | Printable checklists: safety, acceptance, handoff | Books 1–3 |
| `projects/` | Starting material for every project and capstone | Books 1–3 |
| `hooks/` | Annotated, copy-paste hooks | Books 2–3 |
| `tools/` | Maintenance scripts for this repository | — |

[`skills/INDEX.md`](skills/INDEX.md) maps every skill to the chapter that introduces
it.

---

## Verify the kit yourself

```bash
./tools/validate-skills.sh
```

It checks every `SKILL.md` against the rules in the books: valid frontmatter, a
description that states when to use the skill, the 1,536-character listing limit,
no unknown fields, and a directory name that produces a valid `/command`. Exit
code 0 means everything passed.

This is the same script used before every release of the kit. It is included
because a book about verification that ships unverified files would be a poor
argument for its own thesis.

---

## Reporting a problem

If a skill stopped working after a Claude Code update, that is worth knowing —
it is exactly what the update policy exists for. Include your `claude --version`
output and what you ran.

---

## Licence

See [LICENSE.md](LICENSE.md). Short version: yours to use and modify for your own
work and inside your own organisation; not yours to redistribute or resell.
